
Use multi-thread: 
	app.exe domains.txt 10 wp-search.php
	app.exe LIST THREADS SCRIPT.PHP
	
Use PHP script:	
	php wp-search.php 1 host.net
